
License Plates - v3 2021-03-28 11:44am
==============================

This dataset was exported via roboflow.ai on April 2, 2021 at 2:09 PM GMT

It includes 350 images.
Plates are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


