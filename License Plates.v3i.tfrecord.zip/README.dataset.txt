# License Plates > 2021-03-28 11:44am
https://public.roboflow.ai/object-detection/license-plates-us-eu

Provided by [Roboflow](https://roboflow.com)
License: Public Domain

