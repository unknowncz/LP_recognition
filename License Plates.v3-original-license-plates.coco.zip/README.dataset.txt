# License Plates > Original License Plates
https://public.roboflow.ai/object-detection/license-plates-us-eu

Provided by [Roboflow](https://roboflow.com)
License: Public Domain

